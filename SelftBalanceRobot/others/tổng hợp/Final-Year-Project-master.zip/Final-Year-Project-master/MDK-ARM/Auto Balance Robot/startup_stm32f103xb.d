auto balance robot\startup_stm32f103xb.o: startup_stm32f103xb.s
